package com.example.couchbaselite;


import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.couchbase.lite.CouchbaseLite;
import com.couchbase.lite.CouchbaseLiteException;
import com.couchbase.lite.DataSource;
import com.couchbase.lite.Database;
import com.couchbase.lite.DatabaseConfiguration;
import com.couchbase.lite.Document;
import com.couchbase.lite.MutableDocument;
import com.couchbase.lite.Query;
import com.couchbase.lite.QueryBuilder;
import com.couchbase.lite.Result;
import com.couchbase.lite.ResultSet;
import com.couchbase.lite.SelectResult;

public class MainActivity extends AppCompatActivity {

    private static final Object TAG = "Lag";
    public final static String FIRST_DIGIT = "FIRST_DIGIT";
    public final static String SECOND_DIGIT = "SECOND_DIGIT";
    public final static String DATABASE_NAME = "mydb5";
    protected int first;
    protected int second;
    private EditText firstNumber;
    private EditText secondNumber;
    private TextView primesCount;
    private Database database = null;
    MutableDocument mutableDoc;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        firstNumber = findViewById(R.id.firstNumber);
        secondNumber = findViewById(R.id.secondNumber);
        primesCount = findViewById(R.id.primesCount);
        primesCount.setVisibility(View.GONE);

        CouchbaseLite.init(this);

        DatabaseConfiguration config = new DatabaseConfiguration();
        mutableDoc = new MutableDocument();


        System.out.println(Database.exists(DATABASE_NAME, this.getFilesDir()));
        if (!Database.exists(DATABASE_NAME, this.getFilesDir())) {
            mutableDoc.setInt(FIRST_DIGIT, 2)
                    .setInt(SECOND_DIGIT, 5);

            try {
                database = new Database(DATABASE_NAME, config);
                database.save(mutableDoc);
            } catch (CouchbaseLiteException ex) {
                ex.printStackTrace();
            }
        } else {
            try {
                database = new Database(DATABASE_NAME, config);
            } catch (CouchbaseLiteException ex) {
                ex.printStackTrace();
            }
        }


        //mutableDoc = database.getDocument("e9a2fa5f-4b76-4af5-836e-bfddb346e4e3").toMutable();
        //mutableDoc = database.getDocument(database.)
        Document document = database.getDocument(mutableDoc.getId());
        System.out.println(document);
        Query query = QueryBuilder.select(
                SelectResult.property(FIRST_DIGIT),
                SelectResult.property(SECOND_DIGIT)
        )
                .from(DataSource.database(database));

        try {
            ResultSet rs = query.execute();
            for (Result result : rs) {
                first = result.getInt(FIRST_DIGIT);
                System.out.println("First" + first);
                second = result.getInt(SECOND_DIGIT);
                System.out.println("Second" + second);

            }
        } catch (CouchbaseLiteException e) {
            // Log.e("Sample", e.getLocalizedMessage());
        }

        // Create a new document (i.e. a record) in the database.


//
//
//// Save it to the database.
//        try {
//            database.save(mutableDoc);
//        } catch (CouchbaseLiteException ex) {
//            ex.printStackTrace();
//        }
    }


    @Override
    protected void onResume() {
        super.onResume();
        System.out.println(firstNumber.getText());
        System.out.println(first);
        firstNumber.setText(String.valueOf(first));
        secondNumber.setText(String.valueOf(second));
    }

    public void showCountOfPrimes(View view) { // zamiast onClickListener mozna zadeklarowac w activity_main.xml dla konkretnego komponentu onClick:'nazwa_metody' - krócej trochę w kodzie :)
        String output = String.valueOf(getCount());
        primesCount.setText(getApplicationContext().getResources().getQuantityString(R.plurals.primes_text, Integer.parseInt(output), output)); //TODO w zaleznosci od ilosci wyswietla sie inny string
        primesCount.setVisibility(View.VISIBLE); //TODO pokazujemy napis dopiero po kliknięciu w przycisk
    }

    public void saveData(View view) {
        first = Integer.parseInt(firstNumber.getText().toString());
        second = Integer.parseInt(secondNumber.getText().toString());
        mutableDoc.setInt(FIRST_DIGIT, first)
                .setInt(SECOND_DIGIT, second);

        try {
            database.save(mutableDoc);
            showToast(R.string.data_saved);
        } catch (CouchbaseLiteException ex) {
            showToast(R.string.data_not_saved);
            ex.printStackTrace();
        }
    }

    private void showToast(int message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    private int getCount() {
        first = Integer.parseInt(firstNumber.getText().toString());
        second = Integer.parseInt(secondNumber.getText().toString());
        if (first > second) {
            int tmp = second;
            second = first;
            first = tmp;
        }
        int count = 0;
        for (int i = first; i <= second; i++) {

            boolean flag = false;
            for (int j = 2; j <= i / 2; ++j) {
                if (i % j == 0) {
                    flag = true;
                    break;
                }
            }
            if (!flag)
                count++;
        }
        return count;
    }
}